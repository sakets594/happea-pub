$(document).ready(function () {
    $("#male").click(function () {
        $(".change_content").html("<h1 class=\"my-4 text-center text-lg-left img_heading animated bounceIn\">How Many Happy years ?</h1>\n"+
                "<div class=\"row text-center text-lg-left animated fadeInLeft img_div\">\n"+
                    "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n"+
                        "<a href=\"#\" class=\"d-block mb-4 h-100 \">\n"+
                            "<img class=\"img-fluid img_enlarge\" src=\"images/change/teenage.png\" alt=\"\">\n"+
                        "</a>\n"+
                    "</div>\n"+
                    "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n"+
                       "<a href=\"#\" class=\"d-block mb-4 h-100\">\n"+
                            "<img class=\"img - fluid img_enlarge\" src=\"images/change/youth.png\" alt=\"\">\n"+
                        "</a>\n"+
                    "</div>\n"+
                    "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n"+
                        "<a href=\"#\" class=\"d-block mb-4 h-100 \">\n"+
                            "<img class=\"img-fluid img_enlarge\" src=\"images/change/middle_age.png\" alt=\"\">\n"+
                        "</a>\n"+
                    "</div>\n"+
                    "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n"+
                        "<a href=\"#\" class=\"d-block mb-4 h-100 \">\n"+
                            "<img class=\"img-fluid img_enlarge\" src=\"images/change/old.png\" alt=\"\">\n"+
                        "</a>\n"+
                    "</div>\n"+
                "</div>");
    });
});

$(document).ready(function () {
    $("#female").click(function () {
        $(".change_content").html("<h1 class=\"my-4 text-center text-lg-left img_heading animated bounceIn\">How Many Happy years ?</h1>\n" +
            "<div class=\"row text-center text-lg-left animated fadeInLeft img_div\">\n" +
            "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n" +
            "<a href=\"#\" class=\"d-block mb-4 h-100 \">\n" +
            "<img class=\"img-fluid img_enlarge\" src=\"images/change/teen_women.png\" alt=\"\">\n" +
            "</a>\n" +
            "</div>\n" +
            "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n" +
            "<a href=\"#\" class=\"d-block mb-4 h-100\">\n" +
            "<img class=\"img - fluid img_enlarge\" src=\"images/change/youth_women.png\" alt=\"\">\n" +
            "</a>\n" +
            "</div>\n" +
            "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n" +
            "<a href=\"#\" class=\"d-block mb-4 h-100 \">\n" +
            "<img class=\"img-fluid img_enlarge\" src=\"images/change/middle_women.png\" alt=\"\">\n" +
            "</a>\n" +
            "</div>\n" +
            "<div class=\"col-lg-3 col-md-4 col-xs-6\">\n" +
            "<a href=\"#\" class=\"d-block mb-4 h-100 \">\n" +
            "<img class=\"img-fluid img_enlarge\" src=\"images/change/old_women.png\" alt=\"\">\n" +
            "</a>\n" +
            "</div>\n" +
            "</div>");
    });
});

